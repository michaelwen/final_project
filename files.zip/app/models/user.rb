require 'bcrypt'

class User < ActiveRecord::Base
  validates :name, presence: true
  validates :name, uniqueness: true
  validates :name, length: { minimum: 2 }
  validates :email, presence: true
  validate :name_must_be_capitalized
  has_many :groups_users, dependent: :destroy
  has_many :groups, through: :groups_users
  has_many :statuses

  include BCrypt

  def name_must_be_capitalized
    if !name == name.capitalize
      errors.add(:name, "name is not capitalized")
    end
  end

  def password
    @password ||= Password.new(password_hash)
  end

  def password=(new_password)
    @password = Password.create(new_password)
    self.password_hash = @password
  end

end
