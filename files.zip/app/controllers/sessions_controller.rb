class SessionsController < ApplicationController
  def new
  end

  def create
    sessions[:user_id] = current_user.id
  end

  def destroy
    reset_session
    redirect_to '/'
  end
end
